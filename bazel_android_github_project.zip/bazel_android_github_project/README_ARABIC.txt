طريقة الاستعمال من الهاتف:

1) أنشئ Repository جديد في GitHub.
2) ارفع كل محتوى هذا المجلد، وليس الملف المضغوط كما هو.
3) ادخل إلى تبويب Actions.
4) اختر Build Android APK.
5) اضغط Run workflow.
6) بعد انتهاء البناء افتح آخر عملية، ثم حمّل Artifact باسم BazelPuzzle-debug-apk.
7) داخل الملف ستجد app-debug.apk.

ملاحظة:
ملف HTML موجود داخل:
app/src/main/assets/index.html

إذا أردت تغيير التطبيق لاحقًا، عوّض فقط هذا الملف بنفس الاسم index.html ثم شغّل Actions من جديد.
